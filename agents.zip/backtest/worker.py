"""
Module worker isolé pour les backtests parallèles.

Ce module est séparé de l'UI Streamlit pour éviter les problèmes de pickling
quand Streamlit recharge ses modules (hot-reload).

La fonction `run_backtest_worker` est stable et ne change pas de référence
pendant l'exécution d'un sweep.

PERFORMANCE NOTE (#3): Imports lourds ~100-300ms par worker au démarrage.
C'est une limitation intrinsèque de Windows multiprocessing 'spawn' mode.
Avec 24 workers: ~7s de latence initiale (coût fixe unique).
"""
from __future__ import annotations

import os
from typing import Any, Dict

# Ces imports sont faits au niveau du module pour être disponibles dans les workers
# ⚠️ FIX #3: Import coûteux mais inévitable avec Windows spawn mode
try:
    from backtest.engine import BacktestEngine
except ImportError:
    BacktestEngine = None

# Variable globale pour le DataFrame (partagée entre tous les backtests d'un worker)
# Initialisée une seule fois par worker via init_worker_with_dataframe()
_worker_dataframe = None
_worker_strategy_key = None
_worker_symbol = None
_worker_timeframe = None
_worker_initial_capital = None
_worker_debug_enabled = False
_worker_fast_metrics = True  # ⚡ Performance: verrouillage mode rapide (536 bt/s vs 85 bt/s)
_worker_period_days = None
_worker_engine = None
_worker_indicator_cache = None  # Cache des indicateurs calculés

# GPU Queue globals pour calcul parallèle des indicateurs
_worker_gpu_request_queue = None
_worker_gpu_response_queue = None


def _apply_numba_thread_limit(thread_limit: int, debug_enabled: bool = False) -> None:
    """Applique une limite réelle aux kernels Numba CPU parallèles."""
    if thread_limit <= 0:
        return

    try:
        from numba import get_num_threads, set_num_threads

        set_num_threads(thread_limit)

        if debug_enabled:
            import logging

            logger = logging.getLogger(__name__)
            logger.debug("Numba thread limit applied: %d", get_num_threads())
    except ImportError:
        return
    except Exception as e:
        if debug_enabled:
            import logging

            logger = logging.getLogger(__name__)
            logger.warning("numba thread configuration failed: %s", e)


def init_worker_with_dataframe(
    df_or_path,
    strategy_key: str,
    symbol: str,
    timeframe: str,
    initial_capital: float,
    debug_enabled: bool,
    thread_limit: int,
    fast_metrics: bool = True,  # ⚡ Performance: mode rapide par défaut
    is_path: bool = False,
):
    """
    Initializer pour ProcessPoolExecutor - charge le DataFrame une seule fois.

    CRITICAL: Toute exception ici casse le pool entier (BrokenProcessPool).
    On wrappe tout dans try/except pour logger les erreurs avant crash.
    """
    # ⚡ Performance: désactiver cache disque indicateur (contention I/O en parallèle)
    # Cache mémoire reste actif pour indicateurs réutilisables
    os.environ["INDICATOR_CACHE_DISK_ENABLED"] = "0"

    try:
        _init_worker_with_dataframe_impl(
            df_or_path, strategy_key, symbol, timeframe,
            initial_capital, debug_enabled, thread_limit,
            fast_metrics, is_path
        )
    except Exception as e:
        # CRITICAL: Logger l'erreur avant que le worker ne crash
        import sys, traceback
        print(f"❌ FATAL: Worker init failed: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        sys.stderr.flush()
        raise  # Re-raise pour signaler l'échec au pool


def _init_worker_with_dataframe_impl(
    df_or_path,
    strategy_key: str,
    symbol: str,
    timeframe: str,
    initial_capital: float,
    debug_enabled: bool,
    thread_limit: int,
    fast_metrics: bool = True,
    is_path: bool = False,
):
    """
    Implémentation réelle de l'initializer (wrappée pour error handling).

    ✅ FIX CRITICAL: Ajouter root du projet au PYTHONPATH (Windows spawn mode)
    Les workers importent ui/main.py mais n'ont pas 'ui' dans leur sys.path.
    """
    # ═══════════════════════════════════════════════════════════════════════════
    # FIX PYTHONPATH - CRITICAL POUR WINDOWS SPAWN MODE
    # ═══════════════════════════════════════════════════════════════════════════
    import sys
    from pathlib import Path
    project_root = Path(__file__).parent.parent  # d:\backtest_core_v2
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    """
    Cette fonction est appelée une fois par worker au démarrage du pool.
    Le DataFrame est stocké en variable globale pour éviter la sérialisation pickle
    répétée à chaque soumission de tâche.

    IMPORTANT: Application ROBUSTE des limites de threads BLAS pour éviter
    nested parallelism (8 workers × 16 threads BLAS = 128 threads → surcharge CPU).
    La limitation est appliquée PROGRAMMATIQUEMENT, pas seulement via env vars.

    Args:
        df_or_path: DataFrame OHLCV complet OU chemin vers fichier parquet (si is_path=True)
        strategy_key: Nom de la stratégie
        symbol: Symbole (ex: BTCUSDC)
        timeframe: Timeframe (ex: 1h)
        initial_capital: Capital initial
        debug_enabled: Activer logs de debug
        thread_limit: Limite de threads CPU (0 = auto-detect, recommandé: 1)
        fast_metrics: Utiliser les métriques rapides pour les sweeps
        is_path: Si True, df_or_path est un chemin de fichier à charger

    Note:
        GPU queues sont automatiquement récupérées depuis GPUContextManager
        si initialisées par SweepEngine.run_sweep() avant le lancement des workers.
    """
    global _worker_dataframe, _worker_strategy_key, _worker_symbol
    global _worker_timeframe, _worker_initial_capital, _worker_debug_enabled
    global _worker_fast_metrics, _worker_period_days, _worker_engine
    global _worker_gpu_request_queue, _worker_gpu_response_queue
    global _worker_sweep_ready

    # Charger le DataFrame depuis le fichier ou utiliser celui fourni
    if is_path:
        import pandas as pd
        _worker_dataframe = pd.read_parquet(df_or_path)
    else:
        _worker_dataframe = df_or_path
    _worker_strategy_key = strategy_key
    _worker_symbol = symbol
    _worker_timeframe = timeframe
    _worker_initial_capital = initial_capital
    _worker_debug_enabled = debug_enabled
    _worker_fast_metrics = fast_metrics
    _worker_engine = None

    # Réinitialiser le cache d'indicateurs pour ce worker
    # ⚠️ FIX #6: Cache existant mais non utilisé efficacement
    # TODO: Implémenter cache smart avec clés basées sur (indicator_name, params, data_hash)
    # Gain potentiel: 20-30% de performance sur stratégies avec indicateurs répétés
    global _worker_indicator_cache
    _worker_indicator_cache = {}

    # Mode CPU-only: pas de queues GPU

    # Pré-calcul du nombre de jours (évite coût répété)
    _worker_period_days = None
    try:
        import pandas as pd
        start_day = pd.to_datetime(_worker_dataframe.index[0]).date()
        end_day = pd.to_datetime(_worker_dataframe.index[-1]).date()
        days = (end_day - start_day).days
        _worker_period_days = days if days > 0 else None
    except (ImportError, AttributeError, IndexError, TypeError):
        _worker_period_days = None

    # ═══════════════════════════════════════════════════════════════════════════
    # LIMITATION THREADS BLAS - APPLICATION PROGRAMMATIQUE ROBUSTE
    # ═══════════════════════════════════════════════════════════════════════════
    # PROBLÈME: Sans limitation, NumPy/SciPy utilise tous les cœurs par worker
    #   → 8 workers × 16 threads BLAS = 128 threads → surcharge CPU massive
    # SOLUTION: Forcer 1 thread BLAS par worker de manière programmatique
    #   → 8 workers × 1 thread BLAS = 8 threads → charge CPU optimale
    # ═══════════════════════════════════════════════════════════════════════════

    # Déterminer la limite effective (défaut: 1 thread si non spécifié)
    effective_limit = thread_limit if thread_limit > 0 else 1

    # 1️⃣ Variables d'environnement (fallback pour bibliothèques qui ne supportent pas threadpoolctl)
    os.environ["BACKTEST_WORKER_THREADS"] = str(effective_limit)
    for var in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "BLIS_NUM_THREADS",
        "NUMBA_NUM_THREADS",  # 🚀 CRITIQUE: Éviter nested parallelism Numba dans workers
    ):
        os.environ[var] = str(effective_limit)

    # 1bis️⃣ Numba CPU - appliquer la limite après import pour qu'elle soit réellement active
    _apply_numba_thread_limit(effective_limit, debug_enabled=debug_enabled)

    # 2️⃣ threadpoolctl - APPLICATION PROGRAMMATIQUE (priorité haute)
    # C'est LA méthode robuste pour contrôler BLAS même sans env vars
    threadpoolctl_applied = False
    try:
        import threadpoolctl

        # Appliquer limite sur TOUS les thread pools (BLAS, OpenMP, TBB, etc.)
        threadpoolctl.threadpool_limits(limits=effective_limit)
        threadpoolctl_applied = True

        # Vérification (optionnel en debug)
        if debug_enabled:
            info = threadpoolctl.threadpool_info()
            total_threads = sum(pool.get("num_threads", 0) for pool in info)
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(
                "Worker thread limit applied: %d thread(s) across %d pool(s)",
                total_threads,
                len(info),
            )
    except ImportError:
        # threadpoolctl non installé - fallback env vars uniquement
        if debug_enabled:
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(
                "threadpoolctl not available - using env vars only (less reliable)"
            )
    except Exception as e:
        if debug_enabled:
            import logging
            logger = logging.getLogger(__name__)
            logger.warning("threadpoolctl configuration failed: %s", e)

    # 3️⃣ PyTorch (si disponible)
    try:
        import torch
        torch.set_num_threads(effective_limit)
        torch.set_num_interop_threads(max(1, effective_limit // 2))
    except (ImportError, AttributeError):
        pass  # Torch non utilisé ou indisponible

    # 4️⃣ Vérification finale (optionnel - seulement en debug)
    if debug_enabled and not threadpoolctl_applied:
        import logging
        logger = logging.getLogger(__name__)
        logger.warning(
            "⚠️ Thread limiting applied via env vars only - "
            "consider installing threadpoolctl for robust control: "
            "pip install threadpoolctl"
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # 5️⃣ PRÉ-INITIALISATION ENGINE + MODE SWEEP RAPIDE
    # ═══════════════════════════════════════════════════════════════════════════
    _worker_sweep_ready = False
    try:
        if BacktestEngine is not None:
            _worker_engine = BacktestEngine(initial_capital=initial_capital)
            _worker_engine.prepare_sweep(
                _worker_dataframe,
                strategy_key,
                timeframe,
            )
            _worker_sweep_ready = True
    except Exception as exc:
        import logging
        logging.getLogger(__name__).warning("Sweep pre-init failed: %s", exc, exc_info=True)
        _worker_sweep_ready = False
        _worker_engine = None


# Flag pour le mode sweep rapide (initialisé dans init_worker_with_dataframe)
_worker_sweep_ready = False


def run_backtest_worker(param_combo: Dict[str, Any]) -> Dict[str, Any]:
    """
    Worker function pour ProcessPoolExecutor - isolé du hot-reload Streamlit.

    Utilise automatiquement le mode sweep ultra-rapide si prepare_sweep()
    a été appelé dans l'init. Sinon, fallback vers le chemin legacy.

    Args:
        param_combo: Dictionnaire des paramètres de la stratégie à tester

    Returns:
        Dict avec résultats du backtest ou erreur
    """
    global _worker_engine

    # ═══════════════════════════════════════════════════════════════════════
    # ⚡ MODE SWEEP ULTRA-RAPIDE (élimine ~80% overhead Python)
    # Pas de: safe_run_backtest, logger, PerfCounters, strategy lookup,
    #         validation, RunResult, 20+ champs pickle
    # ═══════════════════════════════════════════════════════════════════════
    if _worker_sweep_ready and _worker_engine is not None:
        try:
            metrics = _worker_engine.run_sweep_iteration(param_combo)
            fast_error = metrics.get("_error")
            if fast_error:
                return {
                    "params_dict": param_combo,
                    "error": f"[sweep_fast] {fast_error}",
                }

            total_trades = metrics.get("total_trades", 0)
            return {
                "params_dict": param_combo,
                "total_pnl": metrics.get("total_pnl", 0.0),
                "sharpe": metrics.get("sharpe_ratio", 0.0),
                "win_rate": metrics.get("win_rate_pct", metrics.get("win_rate", 0.0)),
                "max_dd": metrics.get("max_drawdown_pct", metrics.get("max_drawdown", 0.0)),
                "account_ruined": metrics.get("account_ruined", False),
                "total_trades": total_trades,
                "trades": total_trades,
                "profit_factor": metrics.get("profit_factor", 0.0),
                "period_days": _worker_period_days,
            }
        except Exception as e:
            if _worker_debug_enabled:
                import traceback as tb
                err = tb.format_exc()
            else:
                err = str(e)
            return {
                "params_dict": param_combo,
                "error": f"[sweep_fast] {err}",
            }

    # ═══════════════════════════════════════════════════════════════════════
    # 🔄 CHEMIN LEGACY (fallback si prepare_sweep a échoué)
    # ═══════════════════════════════════════════════════════════════════════

    df = _worker_dataframe
    strategy_key = _worker_strategy_key
    symbol = _worker_symbol
    timeframe = _worker_timeframe
    initial_capital = _worker_initial_capital
    debug_enabled = _worker_debug_enabled
    fast_metrics = _worker_fast_metrics

    # Validation
    if df is None:
        return {
            "params_dict": param_combo,
            "error": "Worker not initialized - DataFrame is None",
        }

    period_days = _worker_period_days

    try:
        if BacktestEngine is None:
            return {
                "params_dict": param_combo,
                "error": "BacktestEngine not available in worker",
            }

        # Créer l'engine localement (pas picklable donc recréé dans chaque process)
        # Note: Les limites de threads sont déjà appliquées par init_worker_with_dataframe()
        if _worker_engine is None:
            _worker_engine = BacktestEngine(initial_capital=initial_capital)
        engine = _worker_engine

        try:
            result_i = engine.run(
                df=df,
                strategy=strategy_key,
                params=param_combo,
                symbol=symbol,
                timeframe=timeframe,
                silent_mode=True,
                fast_metrics=fast_metrics,
            )
        except ValueError as exc:
            return {
                "params_dict": param_combo,
                "error": f"Paramètres invalides: {exc}",
            }
        except Exception as exc:
            if debug_enabled:
                import traceback

                error_msg = f"Erreur: {exc}\n{traceback.format_exc()}"
            else:
                error_msg = f"Erreur: {exc}"
            return {
                "params_dict": param_combo,
                "error": error_msg,
            }

        # Extraire les métriques avec fallback robuste
        m = {}
        if hasattr(result_i, "metrics") and result_i.metrics:
            m = result_i.metrics
        elif isinstance(result_i, dict):
            m = result_i.get("metrics", result_i)

        total_trades = m.get("total_trades", 0)
        return {
            "params_dict": param_combo,
            "total_pnl": m.get("total_pnl", 0.0),
            "sharpe": m.get("sharpe_ratio", 0.0),
            "win_rate": m.get("win_rate_pct", m.get("win_rate", 0.0)),
            "max_dd": m.get("max_drawdown_pct", m.get("max_drawdown", 0.0)),
            "account_ruined": m.get("account_ruined", False),
            "min_equity": m.get("min_equity", 0.0),
            "total_trades": total_trades,
            "trades": total_trades,
            "profit_factor": m.get("profit_factor", 0.0),
            "liquidation_total_pnl": m.get("liquidation_total_pnl", m.get("total_pnl", 0.0)),
            "liquidation_total_return_pct": m.get("liquidation_total_return_pct", m.get("total_return_pct", 0.0)),
            "liquidation_sharpe_ratio": m.get("liquidation_sharpe_ratio", m.get("sharpe_ratio", 0.0)),
            "liquidation_max_drawdown_pct": m.get("liquidation_max_drawdown_pct", m.get("max_drawdown_pct", 0.0)),
            "liquidation_triggered": m.get("liquidation_triggered", False),
            "liquidation_time": m.get("liquidation_time"),
            "consecutive_losses_max": m.get("consecutive_losses_max", 0),
            "avg_win_loss_ratio": m.get("avg_win_loss_ratio", 0.0),
            "robustness_score": m.get("robustness_score", 0.0),
            "data_coverage_pct": m.get("data_coverage_pct"),
            "period_days": period_days,
        }

    except Exception as e:
        # Capturer toute erreur d'exécution
        error_msg = str(e)
        if debug_enabled:
            import traceback
            error_msg = traceback.format_exc()
        return {
            "params_dict": param_combo,
            "error": error_msg,
        }
