# LLM Token Matrix Benchmark

- Generated at: 2026-04-05T17:11:05+00:00
- Ollama host: http://127.0.0.1:11434
- Timeframe: 1h
- Tokens: 23
- Runs per model: 1
- Probe models: 1
- Executed runs: 1

## Probe Policies

- full: 1

## Common Errors

- schema_violation: 1

## Top Models

- mistral:7b-instruct | success=0/1 | coverage=100.00% | latency=12164ms

## Probe Only / Skipped

- Aucun modèle en probe-only.
