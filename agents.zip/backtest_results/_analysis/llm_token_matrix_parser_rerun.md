# LLM Token Matrix Benchmark

- Generated at: 2026-04-05T18:07:01+00:00
- Ollama host: http://127.0.0.1:11434
- Timeframe: 1h
- Tokens: 23
- Runs per model: 1
- Probe models: 3
- Executed runs: 3

## Probe Policies

- full: 3

## Common Errors

- token_set_mismatch: 1
- missing_tokens_array: 1

## Top Models

- qwen3-30b-a3b:q4_k_m | success=1/1 | coverage=100.00% | latency=16148ms
- fin-llama-33b:33b | success=0/1 | coverage=4.35% | latency=12902ms
- qwen3-48b-savant:latest | success=0/1 | coverage=0.00% | latency=5728ms

## Probe Only / Skipped

- Aucun modèle en probe-only.
