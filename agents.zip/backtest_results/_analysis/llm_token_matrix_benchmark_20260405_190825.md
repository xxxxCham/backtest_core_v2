# LLM Token Matrix Benchmark

- Generated at: 2026-04-05T17:09:08+00:00
- Ollama host: http://127.0.0.1:11434
- Timeframe: 1h
- Tokens: 23
- Runs per model: 1
- Probe models: 1
- Executed runs: 1

## Probe Policies

- full: 1

## Common Errors

- invalid_json: 1

## Top Models

- mistral:7b-instruct | success=0/1 | coverage=0.00% | latency=16271ms

## Probe Only / Skipped

- Aucun modèle en probe-only.
