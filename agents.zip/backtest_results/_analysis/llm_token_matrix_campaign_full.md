# LLM Token Matrix Benchmark

- Generated at: 2026-04-05T17:58:03+00:00
- Ollama host: http://127.0.0.1:11434
- Timeframe: 1h
- Tokens: 23
- Runs per model: 1
- Probe models: 58
- Executed runs: 25

## Probe Policies

- full: 25
- probe_only_unaccepted: 31
- probe_only_expensive: 2

## Common Errors

- invalid_json: 1
- token_set_mismatch: 4
- timeout: 8
- missing_tokens_array: 3

## Top Models

- martain7r/finance-llama-8b:q4_k_m | success=1/1 | coverage=100.00% | latency=13452ms
- gpt-oss:20b | success=1/1 | coverage=100.00% | latency=15980ms
- mistral:7b-instruct | success=1/1 | coverage=100.00% | latency=16348ms
- qwen3-coder:30b | success=1/1 | coverage=100.00% | latency=16757ms
- lfm2:24b | success=1/1 | coverage=100.00% | latency=18648ms
- fin-o1:14b-q6_k | success=1/1 | coverage=100.00% | latency=37370ms
- nemotron-orchestrator-8b:latest | success=1/1 | coverage=100.00% | latency=40082ms
- devstral-small-2:24b | success=1/1 | coverage=100.00% | latency=44056ms
- gemma3:27b | success=1/1 | coverage=100.00% | latency=47458ms
- nemotron-cascade-14b-thinking-claude-4.5-opus-distill.q8_0:latest | success=0/1 | coverage=100.00% | latency=46845ms

## Probe Only / Skipped

- alia-40b-local | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `alia-40b-local:latest` a expiré.
- cogito-2.1:671b | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `cogito-2.1:671b`.
- deepseek-r1:70b | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `deepseek-r1:70b` a expiré.
- deepseek-v3.1 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `deepseek-v3.1`.
- deepseek-v3.1:671b-cloud | policy=probe_only_expensive | probe=accepted | L'hôte http://127.0.0.1:11434 accepte `deepseek-v3.1:671b-cloud` et le modèle est visible dans /api/tags.
- deepseek-v3.2 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `deepseek-v3.2`.
- devstral-2:123b | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `devstral-2:123b`.
- fin-llama-33b-model.f16 | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `fin-llama-33b-model.f16:latest` a expiré.
- gemma3:12b | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `gemma3:12b` a expiré.
- glm-4.6 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `glm-4.6`.
- glm-4.7 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `glm-4.7`.
- glm-4.7-flash-23b-local | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `glm-4.7-flash-23b-local:latest` a expiré.
- glm-5 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `glm-5`.
- gpt-oss-safeguard:20b | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `gpt-oss-safeguard:20b` a expiré.
- gpt-oss:120b | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `gpt-oss:120b`.
- gpt-oss:120b-cloud | policy=probe_only_expensive | probe=accepted | L'hôte http://127.0.0.1:11434 accepte `gpt-oss:120b-cloud` et le modèle est visible dans /api/tags.
- kimi-k2 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `kimi-k2`.
- kimi-k2-thinking | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `kimi-k2-thinking`.
- kimi-k2.5 | policy=probe_only_unaccepted | probe=exact_name_rejected_by_host | L'hôte http://127.0.0.1:11434 est joignable, mais il rejette le nom exact `kimi-k2.5`.
- llama3.3:70b-instruct-q4_K_M | policy=probe_only_unaccepted | probe=runtime_timeout | L'hôte http://127.0.0.1:11434 est joignable, mais le probe runtime sur `llama3.3:70b-instruct-q4_K_M` a expiré.
